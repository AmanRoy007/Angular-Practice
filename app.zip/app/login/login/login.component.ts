import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms'
import { Router } from '@angular/router';
import { LoginServiceService } from 'src/app/service/login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm:FormGroup;
  emailControlName = "emailControl";
  passwordControlName = "passwordControl";
  isSignUpSuccessfull: boolean;
  notificationMessage:string;


  constructor(private loginService:LoginServiceService, private router:Router) { }

  ngOnInit(): void {
    this.initaliseForm();
  }

  initaliseForm()
  {
    this.loginForm = new FormGroup({
      emailControl : new FormControl('', [Validators.required, Validators.email]),
      passwordControl : new FormControl('',[Validators.required, Validators.minLength(6)]),
    })
  }
  getFormValue()
  {
    if(this.loginForm.valid)
    {
      const userEmail = this.loginForm.value.emailControl;
      const userPassword = this.loginForm.value.passwordControl;
      this.SignUpUser(userEmail, userPassword);
      console.log(this.loginForm.value)
      this.loginForm.reset();
    }
  }

  SignUpUser(email:string, password:string|number)
  {
    this.loginService.SignIn(email, password).subscribe({
      next:response=>{
        if(response !== undefined && response !== null)
        {
          this.isSignUpSuccessfull = true;
          this.notificationMessage = "Login Successsfull";
          this.isSignUpSuccessfull = false;
          this.router.navigateByUrl('/dashboard');
          console.log(response)
        }
      },
      error:error=>{
        console.log("create Acccount error",error)
        if(error instanceof HttpErrorResponse)
        {
          const errorMessage = error.error.error.message;
          this.handleErrorCode(errorMessage)
          
        }
      }
    })
  }

  handleErrorCode(errorMessage:string)
  {
    if(errorMessage === 'EMAIL_EXISTS'){
      setTimeout(()=>{
        this.isSignUpSuccessfull = true;
      }, 100)
      this.isSignUpSuccessfull = false;
      this.notificationMessage = "Email Already exists";
    }
  }

}
