import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {apiConfig} from '../apiConfig/apiConfig';
import {loginRequst} from '../models/data.model';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  apiConfig = apiConfig

  constructor(private http:HttpClient) { }

  public SignUp (email:string, password:string|number)
  {
    return this.http.post<loginRequst>("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" +this.apiConfig.API_KEY, {
    email:email,
    password:password,
    returnSecureToken:true
    });
  }

  public SignIn(email:string, password:string | number)
  {
    return this.http.post<loginRequst>("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key="+this.apiConfig.API_KEY, {
      email : email,
      password : password,
      returnSecureToken:true
    })
  }
}
