import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective } from '@angular/forms';

@Component({
  selector: 'app-textbox',
  templateUrl: './textbox.component.html',
  styleUrls: ['./textbox.component.scss']
})
export class TextboxComponent implements OnInit {

  @Input() formGroup: FormGroup;
  @Input() controlName : string;
  @Input() catagory : string;
  @Input() errorMsg: string;
  @Input() label:string;

  control: FormControl;
  


  constructor(private formBuilder: FormGroupDirective) { }

  ngOnInit(): void {
    this.control = this.formBuilder.control.get(this.controlName) as FormControl;
   
  }

}
