import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LoginServiceService } from '../service/login-service.service';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.scss']
})
export class CreateAccountComponent implements OnInit {

  loginForm:FormGroup;
  emailControlName = "emailControl";
  passwordControlName = "passwordControl";
  isSignUpSuccessfull: boolean;
  notificationMessage:string;


  constructor(private loginService:LoginServiceService) { }

  ngOnInit(): void {
    this.initaliseForm();
  }

  initaliseForm()
  {
    this.loginForm = new FormGroup({
      emailControl : new FormControl('', [Validators.required, Validators.email]),
      passwordControl : new FormControl('',[Validators.required, Validators.minLength(6)]),
    })
  }
  getFormValue()
  {
    if(this.loginForm.valid)
    {
      const userEmail = this.loginForm.value.emailControl;
      const userPassword = this.loginForm.value.passwordControl;
      this.SignUpUser(userEmail, userPassword);
      console.log(this.loginForm.value)
      this.loginForm.reset();
    }
  }

  SignUpUser(email:string, password:string|number)
  {
    this.loginService.SignUp(email, password).subscribe({
      next:response=>{
        if(response !== undefined && response !== null)
        {
          setTimeout(()=>{
            this.isSignUpSuccessfull = true;
          }, 1000)
          this.notificationMessage = "Account Created Successsfully";
          this.isSignUpSuccessfull = false;
          console.log(response)
        }
      },
      error:error=>{
        console.log("create Acccount error",error)
        if(error instanceof HttpErrorResponse)
        {
          const errorMessage = error.error.error.message;
          this.handleErrorCode(errorMessage)
          
        }
      }
    })
  }

  handleErrorCode(errorMessage:string)
  {
    if(errorMessage === 'EMAIL_EXISTS'){
      setTimeout(()=>{
        this.isSignUpSuccessfull = true;
      }, 100)
      this.isSignUpSuccessfull = false;
      this.notificationMessage = "Email Already exists";
    }
  }

}
