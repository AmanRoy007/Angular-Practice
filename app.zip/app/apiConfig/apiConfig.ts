export let apiConfig = {
        LOGIN_URL : "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=",
        API_KEY  : "AIzaSyCDVKV3BgZpHIBmuRgQYddJKUx2G2ijfu4"

}